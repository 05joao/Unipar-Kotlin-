package com.example.recyclerviewapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.trabalhob2.R

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var itemAdapter: ItemAdapter
    private val itemList = mutableListOf<Item>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Verifique se o nome do layout está correto

        // Inicializando a RecyclerView
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Preencher a lista de itens com dados fictícios
        for (i in 1..10) {
            itemList.add(Item("Item $i", ""))
        }

        // Configurando o adapter
        itemAdapter = ItemAdapter(itemList)
        recyclerView.adapter = itemAdapter
    }
}

